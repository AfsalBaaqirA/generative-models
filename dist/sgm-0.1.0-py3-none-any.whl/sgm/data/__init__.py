from .dataset import StableDataModuleFromConfig
